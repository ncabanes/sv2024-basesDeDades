-- TREBALLADOR(dni, nom, adreça, telèfon, e-mail, dniCap)
-- CP: dni
-- CAj: dniCap -> TREBALLADOR

